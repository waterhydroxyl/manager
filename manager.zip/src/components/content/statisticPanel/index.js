import StatisticPanel from './src/StatisticPanel.vue'

export default StatisticPanel
