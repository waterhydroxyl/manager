import PageSearch from './src/PageSearch.vue'

export default PageSearch
