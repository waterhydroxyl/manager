import NavHeader from './src/NavHeader.vue'

export { NavHeader }
