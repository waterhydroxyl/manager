<template>
  <div><h2>NOT FOUNT</h2></div>
</template>

<script>
export default {};
</script>

<style scoped lang="scss"></style>
