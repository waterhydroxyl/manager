import ChhBreadcrumb from './src/ChhBreadcrumb.vue'

export default ChhBreadcrumb
