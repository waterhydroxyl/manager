import PageContent from './src/PageContent'

export default PageContent
