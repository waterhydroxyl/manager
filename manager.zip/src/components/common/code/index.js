import ChhCode from './src/ChhCode.vue'

export default ChhCode
