import ChhTable from './src/ChhTable'

export default ChhTable
