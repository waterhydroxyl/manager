import Countup from './src/Countup.vue'

export default Countup
