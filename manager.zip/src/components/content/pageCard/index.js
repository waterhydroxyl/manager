import PageCard from './src/PageCard.vue'

export default PageCard
