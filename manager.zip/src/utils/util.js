/* 首字母转大写 */
const firstToUpper = (text) => {
  return text.charAt(0).toUpperCase() + text.slice(1)
}

export {
  firstToUpper
}
