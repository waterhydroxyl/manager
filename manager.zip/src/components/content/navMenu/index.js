import navMenu from './src/NavMenu.vue'

export default navMenu
