import PageModal from './src/PageModal.vue'

export default PageModal
