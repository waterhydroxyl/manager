import ChhDescriptions from './src/ChhDescriptions.vue'

export default ChhDescriptions
