import PaginationFooter from './src/PaginationFooter.vue';

export default PaginationFooter;
